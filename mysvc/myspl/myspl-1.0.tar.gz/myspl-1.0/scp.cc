// $Id$

//  myspl - My Service Protocol Library - Version 1.0 (www.mysvc.it)
//  Copyright (C) 2009 Davide Cucciniello <davide6169@gmail.com> 
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

/* **********************************************************************
 *
 *  ***   **        *** **  **  **** 
 *   **  **        *  *  *  ** **  * 
 *   *** **  **  * ***   *  *  *     
 *   * ** *   * **   **   * *  *     
 *   * *  *   * *  *  *   **   **    
 *  ***  ***   **  ***     *    **** 
 *             *                     
 *            *                      
 *
 *  My Service
 *
 * ***********************************************************************
 *                                
 *  ***   **        *** ****  ***   
 *   **  **        *  *  *  *  *    
 *   *** **  **  * ***   *  *  *    
 *   * ** *   * **   **  ***   *    
 *   * *  *   * *  *  *  *     *  * 
 *  ***  ***   **  ***  ***   ***** 
 *             *                    
 *            *                
 *
 *  My Service Protocol Library Example Client 
 *  (Nortel Networks IN SMI Client)
 *
 *  File: scp.cc
 *
 *  Description:
 *    Nortel Networks IN (Intelligent Network) 
 *    SMI (Service Management Interface) Client 
 *    as usage example for MySPL library
 *    (realized for provisioning of VPN service on SCP
 *     in BLU mobile telephone operator)
 *
 * ***********************************************************************
 *
 *  History:
 *    1.0               first version
 *
 * *********************************************************************** */

#include "smi.hh"

// Default parameter values

#define SCP_ADDR       "10.133.11.1"
#define SCP_PORT       5715
#define SCP_USERNAME   "spvpn1"
#define SCP_PASSWORD   "spvpn1"

// Test  parameter values

#define SCP_TEST_ADDR       "10.133.226.26"
#define SCP_TEST_PORT       5715
#define SCP_TEST_USERNAME   "spvpn1"
#define SCP_TEST_PASSWORD   "spvpn1"

// Process return codes 

#define SCP_SUCCESS          0
#define SCP_INTERNAL_ERROR   1
#define SCP_CONNECTION_ERROR 2
#define SCP_LOGIN_ERROR      3
#define SCP_COMMAND_ERROR    4
#define SCP_LOGOUT_ERROR     5

// Commands

#define SCP_COMMAND_NULL                   0
#define SCP_COMMAND_X_DPP_SUBSPIN_ADD      1
#define SCP_COMMAND_X_DPP_SUBSPIN_DEL      2
#define SCP_COMMAND_X_DVPN_PUBLICNUM_QUERY 3
#define SCP_COMMAND_X_DVPN_WHITELIST_ADD   4
#define SCP_COMMAND_X_DVPN_WHITELIST_DEL   5
#define SCP_COMMAND_X_DVPN_DDRPOSITIVE_C00D06_ADD  6
#define SCP_COMMAND_X_DVPN_PRIVATENUM_QUERY 7

/*
 * str2token(string s,char p);
 * 
 * Return the number of tokens of
 * string s, using p as separator
 */

int str2token(string s,char p)
{
  string::size_type i = (string::size_type)-1;
  int n = 0;
 
  while((i = s.find(p,i+1)) != string::npos)
    n++;
  n++; 

  return n;
}

/*
 * str2token(string s,char p,int i);
 *
 * Return the token i of string s,
 * using p as separator
 *   i = 1,..,n 
 *   n = str2token(s,p)
 */

string str2token(string s,char p,int i)
{
  string token;

  int k;

  string::size_type i1 = (string::size_type)-1;
  string::size_type j1; 

  bool hasMoreTokens = (s.find(p,0) != string::npos);

  for(k=0;k<i;k++)
  {
    if(hasMoreTokens)
    {
      j1 = i1 + 1;
      i1 = s.find(p,j1);
      token = s.substr(j1,i1-j1); 
    }
    else
      token = s;
  }

  return token; 
}

void usage() 
{
  cerr << "usage: scp [-s <sms=<addr>[:<port>]>]" << endl;
  cerr << "           [-U <username>]" << endl; 
  cerr << "           [-P <password>]" << endl; 
  cerr << "           [-c <command>]" << endl; 
  cerr << "           [-p <arguments>]" << endl; 
  cerr << "           [-t]" << endl; 
  cerr << "           [-T]" << endl; 
  cerr << "           [-l]" << endl; 
  cerr << endl;
  cerr << "  -t => test"  << endl;
  cerr << "  -T => trace"  << endl;
  cerr << "  -l => log"  << endl;
  cerr << endl;
  cerr << "  <command>:" << endl; 
  cerr << "    x_dpp_subspin_add {msisdn}" << endl;
  cerr << "    x_dpp_subspin_del {msisdn}" << endl;
  cerr << "    x_dvpn_publicnum_query {msisdn}" << endl;
  cerr << "    x_dvpn_privatenum_query {vpnid,privatenumber}" << endl;
  cerr << "    x_dvpn_whitelist_add {vpnid,msisdn}" << endl;
  cerr << "    x_dvpn_whitelist_del {vpnid,msisdn}" << endl;
  cerr << "    x_dvpn_ddrpositive_c00d06_add {vpnid}" << endl;
  cerr << endl;
  cerr << "  examples:" << endl;  
  cerr << "    scp -c x_dpp_subspin_add -p 800123456" << endl; 
  cerr << "    scp -c x_dpp_subspin_del -p 800123456" << endl; 
  cerr << "    scp -c x_dvpn_publicnum_query -p 393801234567" << endl; 
  cerr << "    scp -c x_dvpn_whitelist_add -p 10012345,393801234567" << endl; 
  cerr << "    scp -c x_dvpn_whitelist_del -p 10012345,393801234567" << endl; 
  cerr << "    scp -c x_dvpn_ddrpositive_C00D06_add -p 10012345" << endl; 
  cerr << "    scp -c x_dvpn_privatenum_query -p 10012345,123" << endl; 
  
  exit(1);
}

// Main

int main(int argc,char* argv[])
{
  // Set default parameter values 

  string scp_addr = SCP_ADDR;
  int scp_port = SCP_PORT;

  string scp_sms;

  string scp_username = SCP_USERNAME; 
  string scp_password = SCP_PASSWORD;

  int command = SCP_COMMAND_NULL;

  bool scp_log = false;
  bool scp_trace = false;

  string cmd;

  string cmdargs; 

  // Parsing command line options

  int option;

  while((option = getopt(argc,argv,":hs:U:P:c:p:tlT")) != EOF)
  {
    switch(option)
    {
      case 'h':
        usage();
        break;
      case 's':
        scp_sms = optarg;  
        if(str2token(scp_sms,':') == 1)
          scp_addr = scp_sms; 
        else
        {
          scp_addr = str2token(scp_sms,':',1);
          scp_port = atoi(str2token(scp_sms,':',2).c_str());
        }

        break;
      case 'U':
        scp_username = optarg;  
        break;
      case 'P':
        scp_password = optarg;  
        break;
      case 'p':
        cmdargs = optarg;  
        break;
      case 'c':
        cmd = optarg; 

        if(cmd == "x_dpp_subspin_add")
          command = SCP_COMMAND_X_DPP_SUBSPIN_ADD; 
        else if(cmd == "x_dpp_subspin_del")
          command = SCP_COMMAND_X_DPP_SUBSPIN_DEL; 
        else if(cmd == "x_dvpn_publicnum_query")
          command = SCP_COMMAND_X_DVPN_PUBLICNUM_QUERY;
        else if(cmd == "x_dvpn_whitelist_add")
          command = SCP_COMMAND_X_DVPN_WHITELIST_ADD;
        else if(cmd == "x_dvpn_whitelist_del")
          command = SCP_COMMAND_X_DVPN_WHITELIST_DEL;
        else if(cmd == "x_dvpn_ddrpositive_C00D06_add")
          command = SCP_COMMAND_X_DVPN_DDRPOSITIVE_C00D06_ADD;
        else if(cmd == "x_dvpn_privatenum_query")
          command = SCP_COMMAND_X_DVPN_PRIVATENUM_QUERY;
        else
          usage();

        break;
      case 't':
        scp_addr = SCP_TEST_ADDR; 
        scp_port = SCP_TEST_PORT; 

        scp_username = SCP_TEST_USERNAME; 
        scp_password = SCP_TEST_PASSWORD;

        break;
      case 'T':
        scp_trace = true;
        break;
      case 'l':
        scp_log = true;
        break;
    }
  }

  try
  {
    SocketClient client(scp_addr,scp_port);

    if(scp_log)
      cerr << "Connecting to SCP ..." << endl;

    try
    {
      client.connect();
    }
    catch(Exception& e)
    {
      if(scp_log)
        cerr << "Error connecting to SCP ..." << endl;

      return SCP_CONNECTION_ERROR;
    }

    // Login

    SMILogin login(scp_username,scp_password);

    if(scp_log)
      cerr << "Sending login message ..." << endl;

    if(scp_trace)
    {
      login.updateTree(); 

      cerr << "<smi>" << endl; 

      cerr << login << endl; 
    }

    client << login;

    SMILoginResp loginresp;

    client >> loginresp;

    if(scp_log)
      cerr << "Received loginresp message ..." << endl;

    if(scp_trace)
      cerr << loginresp << endl; 

    if(scp_log)
      cerr << "Error code: <" << loginresp.getGlobalReturnCode() << ">" << endl;

    if(loginresp.getGlobalReturnCode())
      return SCP_LOGIN_ERROR;

    SMIAuthenticationKey auth = loginresp.getAuthenticationKey();

    // Execute command

    switch(command)
    {
      case SCP_COMMAND_X_DPP_SUBSPIN_ADD:
      {
        // Send request ...

        string msisdn = cmdargs;
        string pin = "0000";

        SMIDPPSubsPINProvUpdate smiprovupdate(msisdn,pin);

        smiprovupdate.setAuthenticationKey(auth);
         
        if(scp_log)
          cerr << "Sending provupdate(x_dpp_subspin) message {" 
               << msisdn << "} ..." 
               << endl;

        if(scp_trace)
        {
          smiprovupdate.updateTree(); 

          cerr << smiprovupdate << endl; 
        }

        client << smiprovupdate;

        // Receive response ...

        if(scp_log)
          cerr << "Waiting for response message ..." << endl;

        SMIProvResp smiprovresp;

        client >> smiprovresp;

        if(scp_log)
          cerr << "Received response message ..." << endl;

        if(scp_trace)
          cerr << smiprovresp << endl; 

        if(scp_log)
          cerr << "Error code: <" << smiprovresp.getReturnCode(0) << ">" << endl;

        cout << smiprovresp.getReturnCode(0) << "," 
             << smiprovresp.getErrorText(0) << endl;

        if(smiprovresp.getReturnCode(0))
        {
          if(scp_log)
            cerr << "Error text: <" << smiprovresp.getErrorText(0) << ">" << endl;
          return SCP_COMMAND_ERROR;
        }

        break;
      }
      case SCP_COMMAND_X_DPP_SUBSPIN_DEL:
      {
        // Send request ...

        string msisdn = cmdargs;

        SMIDPPSubsPINDeactivate smideactivate(msisdn);

        smideactivate.setAuthenticationKey(auth);
         
        if(scp_log)
          cerr << "Sending deactivate(x_dpp_subspin) message {" 
               << msisdn << "} ..." 
               << endl;

        if(scp_trace)
        {
          smideactivate.updateTree(); 

          cerr << smideactivate << endl; 
        }

        client << smideactivate;

        // Receive response ...

        if(scp_log)
          cerr << "Waiting for response message ..." << endl;

        SMIProvResp smiprovresp;

        client >> smiprovresp;

        if(scp_log)
          cerr << "Received response message ..." << endl;

        if(scp_trace)
          cerr << smiprovresp << endl; 

        if(scp_log)
          cerr << "Error code: <" << smiprovresp.getReturnCode(0) << ">" << endl;

        cout << smiprovresp.getReturnCode(0) << "," 
             << smiprovresp.getErrorText(0) << endl;

        if(smiprovresp.getReturnCode(0))
        {
          if(scp_log)
            cerr << "Error text: <" << smiprovresp.getErrorText(0) << ">" << endl;
          return SCP_COMMAND_ERROR;
        }

        break;
      }
      case SCP_COMMAND_X_DVPN_PUBLICNUM_QUERY:
      {
        // Send request ...

        string msisdn = cmdargs;

        SMIDVPNPublicNumDBQuery smidbquery(msisdn);

        smidbquery.setAuthenticationKey(auth);

        if(scp_log)
          cerr << "Sending dbquery(x_dvpn_publicnum) message {" 
               << msisdn << "} ..." 
               << endl;

        if(scp_trace)
        {
          smidbquery.updateTree();

          cerr << smidbquery << endl;
        }

        client << smidbquery;

        // Receive response ...

        if(scp_log)
          cerr << "Waiting for response message ..." << endl;

        SMIDVPNPublicNumDBQueryResp smidbqueryresp;

        client >> smidbqueryresp;

        if(scp_log)
          cerr << "Received response message ..." << endl;

        if(scp_trace)
          cerr << smidbqueryresp << endl;

        if(scp_log)
          cerr << "Error code: <" << smidbqueryresp.getGlobalReturnCode() << ">" << endl;

        if(smidbqueryresp.getGlobalReturnCode())
        {
          cout << smidbqueryresp.getGlobalReturnCode() << "," 
               << msisdn << endl;

          return SCP_COMMAND_ERROR;
        }
        else
        {
          unsigned long int numberofmatchingrecords =
            smidbqueryresp.getNumberOfMatchingRecords();

          if(scp_log)
            cerr << "Number of matching records: <" << numberofmatchingrecords << ">" << endl;

          if(numberofmatchingrecords)
            cout << "0," 
                 << msisdn << ","
                 << smidbqueryresp.getBusinessGroupID() << ","
                 << smidbqueryresp.getPrivateNumber() << ","
                 << smidbqueryresp.getOrigTemplateID() << ","
                 << smidbqueryresp.getTermTemplateID() << endl; 
        }
         
        break;
      }
      case SCP_COMMAND_X_DVPN_PRIVATENUM_QUERY:
      {
        // Send request ...

        string vpnid = str2token(cmdargs,',',1);
        string privatenumber = str2token(cmdargs,',',2);

        SMIDVPNPrivateNumDBQuery smidbquery(vpnid,privatenumber);

        smidbquery.setAuthenticationKey(auth);

        if(scp_log)
          cerr << "Sending dbquery(x_dvpn_privatenum) message {" 
               << vpnid << "," << privatenumber << "} ..." 
               << endl;

        if(scp_trace)
        {
          smidbquery.updateTree();

          cerr << smidbquery << endl;
        }

        client << smidbquery;

        // Receive response ...

        if(scp_log)
          cerr << "Waiting for response message ..." << endl;

        SMIDVPNPrivateNumDBQueryResp smidbqueryresp;

        client >> smidbqueryresp;

        if(scp_log)
          cerr << "Received response message ..." << endl;

        if(scp_trace)
          cerr << smidbqueryresp << endl;

        if(scp_log)
          cerr << "Error code: <" << smidbqueryresp.getGlobalReturnCode() << ">" << endl;

        if(smidbqueryresp.getGlobalReturnCode())
        {
          cout << smidbqueryresp.getGlobalReturnCode() << "," 
               << vpnid << "," 
               << privatenumber << endl;

          return SCP_COMMAND_ERROR;
        }
        else
        {
          unsigned long int numberofmatchingrecords =
            smidbqueryresp.getNumberOfMatchingRecords();

          if(scp_log)
            cerr << "Number of matching records: <" << numberofmatchingrecords << ">" << endl;

          if(numberofmatchingrecords)
            cout << "0," 
                 << vpnid << ","
                 << privatenumber << ","
                 << smidbqueryresp.getFeatureIndications() << ","
                 << smidbqueryresp.getHomeSiteID() << ","
                 << smidbqueryresp.getPublicNumberCountryCode() << ","
                 << smidbqueryresp.getPublicNumberNetworkDestCode() << ","
                 << smidbqueryresp.getPublicNumberSubscriberNumber() << ","
                 << smidbqueryresp.getClassOfService() << ","
                 << smidbqueryresp.getHomeCellGroup() << ","
                 << smidbqueryresp.getOriginationAlternateBillingNumber() << ","
                 << smidbqueryresp.getOriginationBillingAggregateGroup() << ","
                 << smidbqueryresp.getOnNetAlternateBillingNumber() << ","
                 << smidbqueryresp.getOnNetBillingAggregateGroup() << ","
                 << smidbqueryresp.getOffNetAlternateBillingNumber() << ","
                 << smidbqueryresp.getOffNetBillingAggregateGroup() << endl; 
        }
         
        break;
      }
      case SCP_COMMAND_X_DVPN_WHITELIST_ADD:
      {
        // Send request ...

        string vpnid = str2token(cmdargs,',',1);
        string msisdn = str2token(cmdargs,',',2);

        SMIDVPNWhiteListProvUpdate smiprovupdate(vpnid,msisdn);

        smiprovupdate.setAuthenticationKey(auth);
         
        if(scp_log)
          cerr << "Sending provupdate(x_dvpn_whitelist) message {" 
               << vpnid << "," << msisdn << "} ..." 
               << endl;

        if(scp_trace)
        {
          smiprovupdate.updateTree(); 

          cerr << smiprovupdate << endl; 
        }

        client << smiprovupdate;

        // Receive response ...

        if(scp_log)
          cerr << "Waiting for response message ..." << endl;

        SMIProvResp smiprovresp;

        client >> smiprovresp;

        if(scp_log)
          cerr << "Received response message ..." << endl;

        if(scp_trace)
          cerr << smiprovresp << endl; 

        if(scp_log)
          cerr << "Global error code: <" << smiprovresp.getGlobalReturnCode() << ">" << endl;

        if(smiprovresp.getGlobalReturnCode())
          return SCP_COMMAND_ERROR;

        if(scp_log)
          cerr << "Error code: <" << smiprovresp.getReturnCode(0) << ">" << endl;

        cout << smiprovresp.getReturnCode(0) << "," 
             << smiprovresp.getErrorText(0) << endl;

        if(smiprovresp.getReturnCode(0))
        {
          if(scp_log)
            cerr << "Error text: <" << smiprovresp.getErrorText(0) << ">" << endl;
          return SCP_COMMAND_ERROR;
        }

        break;
      }
      case SCP_COMMAND_X_DVPN_WHITELIST_DEL:
      {
        // Send request ...

        string vpnid = str2token(cmdargs,',',1);
        string msisdn = str2token(cmdargs,',',2);

        SMIDVPNWhiteListDeactivate smideactivate(vpnid,msisdn);

        smideactivate.setAuthenticationKey(auth);
         
        if(scp_log)
          cerr << "Sending deactivate(x_dvpn_whitelist) message {" 
               << vpnid << "," << msisdn << "} ..." 
               << endl;

        if(scp_trace)
        {
          smideactivate.updateTree(); 

          cerr << smideactivate << endl; 
        }

        client << smideactivate;

        // Receive response ...

        if(scp_log)
          cerr << "Waiting for response message ..." << endl;

        SMIProvResp smiprovresp;

        client >> smiprovresp;

        if(scp_log)
          cerr << "Received response message ..." << endl;

        if(scp_trace)
          cerr << smiprovresp << endl; 

        if(scp_log)
          cerr << "Error code: <" << smiprovresp.getReturnCode(0) << ">" << endl;

        cout << smiprovresp.getReturnCode(0) << "," 
             << smiprovresp.getErrorText(0) << endl;

        if(smiprovresp.getReturnCode(0))
        {
          if(scp_log)
            cerr << "Error text: <" << smiprovresp.getErrorText(0) << ">" << endl;
          return SCP_COMMAND_ERROR;
        }

        break;
      }
      case SCP_COMMAND_X_DVPN_DDRPOSITIVE_C00D06_ADD:
      {
        // Send request ...

        string vpnid = cmdargs;

        SMIDVPNDDRPositiveC00D06ProvUpdate smiprovupdate(vpnid);

        smiprovupdate.setAuthenticationKey(auth);
         
        if(scp_log)
          cerr << "Sending provupdate(x_dvpn_ddrpositive_C00D06) message {" 
               << vpnid << "} ..." 
               << endl;

        if(scp_trace)
        {
          smiprovupdate.updateTree(); 

          cerr << smiprovupdate << endl; 
        }

        client << smiprovupdate;

        // Receive response ...

        if(scp_log)
          cerr << "Waiting for response message ..." << endl;

        SMIProvResp smiprovresp(1);

        client >> smiprovresp;

        if(scp_log)
          cerr << "Received response message ..." << endl;

        if(scp_log)
          cerr << "Global error code: <" << smiprovresp.getGlobalReturnCode() << ">" << endl;

        if(scp_trace)
          cerr << smiprovresp << endl; 

        if(scp_log)
          cerr << "Error code: <" << smiprovresp.getReturnCode(0) << ">" << endl;

        cout << smiprovresp.getReturnCode(0) << "," 
             << smiprovresp.getErrorText(0) << endl;

        if(smiprovresp.getReturnCode(0))
        {
          if(scp_log)
            cerr << "Error text: <" << smiprovresp.getErrorText(0) << ">" << endl;
          return SCP_COMMAND_ERROR;
        }

        break;
      }
    }

    // Logout

    SMILogout logout;

    logout.setAuthenticationKey(auth);

    if(scp_log)
      cerr << "Sending logout message ..." << endl;

    if(scp_trace)
    {
      logout.updateTree(); 

      cerr << logout << endl; 
    }

    client << logout;

    SMILogoutResp logoutresp;

    if(scp_log)
      cerr << "Receiving logoutresp message ..." << endl;

    client >> logoutresp;

    if(scp_trace)
    {
      cerr << logoutresp;

      cerr << "</smi>" << endl; 
    }

    if(scp_log)
      cerr << "Error code: <" << logoutresp.getGlobalReturnCode() << ">" << endl;

    if(logoutresp.getGlobalReturnCode())
      return SCP_LOGOUT_ERROR;
  }
  catch(Exception& e)
  {
     cerr << e << endl;

     return 1;
  }

  return 0;
}

/*
 * End of file
 */

