// $Id$

//  myspl - My Service Protocol Library - Version 1.0 (www.mysvc.it)
//  Copyright (C) 2009 Davide Cucciniello <davide6169@gmail.com> 
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

/* **********************************************************************
 *
 *  ***   **        *** **  **  **** 
 *   **  **        *  *  *  ** **  * 
 *   *** **  **  * ***   *  *  *     
 *   * ** *   * **   **   * *  *     
 *   * *  *   * *  *  *   **   **    
 *  ***  ***   **  ***     *    **** 
 *             *                     
 *            *                      
 *
 *  My Service
 *
 * ***********************************************************************
 *                                
 *  ***   **        *** ****  ***   
 *   **  **        *  *  *  *  *    
 *   *** **  **  * ***   *  *  *    
 *   * ** *   * **   **  ***   *    
 *   * *  *   * *  *  *  *     *  * 
 *  ***  ***   **  ***  ***   ***** 
 *             *                    
 *            *                
 *
 *  My Service Protocol Library Example Client (Wildfire VMS Client)
 *
 *  File: upsp.hh
 *
 *  Description:
 *    Wildfire VMS Client as usage example for MySPL library
 *    (realized for provisioning of "Memory" service 
 *     in BLU mobile telephone operator)
 *
 * ***********************************************************************
 *
 *  History:
 *    1.0               first version
 *
 * *********************************************************************** */

#ifndef _UPSP_HH_
#define _UPSP_HH_

#include "protocol.hh"

// ---------------------------------
// 
//  UPSP Messages 
// 
// ---------------------------------

#define UPSP_VERSION            10
#define UPSP_UNIVERSAL_NACK     11
#define UPSP_LOGIN_REQ          1
#define UPSP_LOGIN_ACK          2
#define UPSP_LOGIN_NACK         3
#define UPSP_LOGOUT_REQ         4
#define UPSP_LOGOUT_ACK         5
#define UPSP_LOGOUT_NACK        6
#define UPSP_LOOP_REQ           7
#define UPSP_LOOP_ACK           8
#define UPSP_LOOP_NACK          9
#define UPSP_CREATE_REQ         12 
#define UPSP_CREATE_ACK         13 
#define UPSP_CREATE_NACK        14 
#define UPSP_SET_REQ            15
#define UPSP_SET_ACK            16
#define UPSP_SET_NACK           17
#define UPSP_GET_ALL_REQ        18
#define UPSP_GET_ALL_ACK        19
#define UPSP_GET_ALL_NACK       20 
#define UPSP_FIND_REQ           21 
#define UPSP_FIND_ACK           22 
#define UPSP_FIND_NACK          23 
#define UPSP_REMOVE_SUBSC_REQ   39 
#define UPSP_REMOVE_SUBSC_ACK   40 
#define UPSP_REMOVE_SUBSC_NACK  41 

//
// HEADER 
//

class UPSPHeader: public Message
{
  public:
    UPSPHeader():
      Message(4,"HEADER")
    {
      // Header fields 
      assign(0,new Int4Field("length"));  
      assign(1,new Int2Field("msg_type"));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  
    }
};

//
// VERSION
//

class UPSPVersion: public Message
{
  public:
    UPSPVersion():
      Message(5,"VERSION")
    {
      // Header fields 
      assign(0,new Int4Field("length",18));  
      assign(1,new Int2Field("msg_type",UPSP_VERSION));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body field
      assign(4,new Int4Field("version",4));  
    }
};

//
// UNIVERSAL_NACK 
//

class UPSPUniversalNAck: public Message
{
  public:
    UPSPUniversalNAck():
      Message(6,"UNIVERSAL_NACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",530));  
      assign(1,new Int2Field("msg_type",UPSP_UNIVERSAL_NACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body fields
      assign(4,new Int4Field("error_code"));  
      assign(5,new StringField(512,"error_msg"));  
    }
};

//
// UNIVERSAL_NACK Body
//

class UPSPUniversalNAckBody: public Message
{
  public:
    UPSPUniversalNAckBody():
      Message(2,"UNIVERSAL_NACK_BODY")
    {
      // Body fields
      assign(0,new Int4Field("error_code"));  
      assign(1,new StringField(512,"error_msg"));  
    }
};

//
// LOGIN_REQ
//

class UPSPLoginReq: public Message
{
  public:
    UPSPLoginReq():
      Message(6,"LOGIN_REQ")
    {
      // Header fields 
      assign(0,new Int4Field("length",71));  
      assign(1,new Int2Field("msg_type",UPSP_LOGIN_REQ));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body fields
      assign(4,new StringField(32,"username"));  // to init 
      assign(5,new StringField(25,"password"));  // to init 
    }
};

//
// LOGIN_ACK
//

class UPSPLoginAck: public Message
{
  public:
    UPSPLoginAck():
      Message(4,"LOGIN_ACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",14));  
      assign(1,new Int2Field("msg_type",UPSP_LOGIN_ACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  
    }
};

//
// LOGIN_NACK
//

class UPSPLoginNAck: public Message
{
  public:
    UPSPLoginNAck():
      Message(6,"LOGIN_NACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",530));  
      assign(1,new Int2Field("msg_type",UPSP_LOGIN_NACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body fields
      assign(4,new Int4Field("error_code"));  
      assign(5,new StringField(512,"error_msg"));  
    }
};

//
// LOGIN_NACK Body
//

class UPSPLoginNAckBody: public Message
{
  public:
    UPSPLoginNAckBody():
      Message(2,"LOGIN_NACK_BODY")
    {
      // Body fields
      assign(0,new Int4Field("error_code"));  
      assign(1,new StringField(512,"error_msg"));  
    }
};

//
// LOGOUT_REQ
//

class UPSPLogoutReq: public Message
{
  public:
    UPSPLogoutReq():
      Message(4,"LOGOUT_REQ")
    {
      // Header fields 
      assign(0,new Int4Field("length",14));  
      assign(1,new Int2Field("msg_type",UPSP_LOGOUT_REQ));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  
    }
};

//
// LOGOUT_ACK
//

class UPSPLogoutAck: public Message
{
  public:
    UPSPLogoutAck():
      Message(4,"LOGOUT_ACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",14));  
      assign(1,new Int2Field("msg_type",UPSP_LOGOUT_ACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  
    }
};

//
// LOGOUT_NACK
//

class UPSPLogoutNAck: public Message
{
  public:
    UPSPLogoutNAck():
      Message(6,"LOGOUT_NACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",530));  
      assign(1,new Int2Field("msg_type",UPSP_LOGOUT_NACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body fields
      assign(4,new Int4Field("error_code"));  
      assign(5,new StringField(512,"error_msg"));  
    }
};

//
// LOGOUT_NACK Body
//

class UPSPLogoutNAckBody: public Message
{
  public:
    UPSPLogoutNAckBody():
      Message(2,"LOGOUT_NACK_BODY")
    {
      // Body fields
      assign(0,new Int4Field("error_code"));  
      assign(1,new StringField(512,"error_msg"));  
    }
};

//
// LOOP_REQ
//

class UPSPLoopReq: public Message
{
  public:
    UPSPLoopReq():
      Message(5,"LOOP_REQ")
    {
      // Header fields 
      assign(0,new Int4Field("length",18));  
      assign(1,new Int2Field("msg_type",UPSP_LOOP_REQ));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body field
      assign(4,new Int4Field("count"));  
    }
};

//
// LOOP_ACK
//

class UPSPLoopAck: public Message
{
  public:
    UPSPLoopAck():
      Message(5,"LOOP_ACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",18));  
      assign(1,new Int2Field("msg_type",UPSP_LOOP_ACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body field
      assign(4,new Int4Field("count"));  
    }
};

//
// LOOP_ACK Body
//

class UPSPLoopAckBody: public Message
{
  public:
    UPSPLoopAckBody():
      Message(1,"LOOP_ACK_BODY")
    {
      // Body field
      assign(0,new Int4Field("count"));  
    }
};

//
// LOOP_NACK
//

class UPSPLoopNAck: public Message
{
  public:
    UPSPLoopNAck():
      Message(6,"LOOP_NACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",530));  
      assign(1,new Int2Field("msg_type",UPSP_LOOP_NACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body fields
      assign(4,new Int4Field("error_code"));  
      assign(5,new StringField(512,"error_msg"));  
    }
};

//
// LOOP_NACK Body
//

class UPSPLoopNAckBody: public Message
{
  public:
    UPSPLoopNAckBody():
      Message(2,"LOOP_NACK_BODY")
    {
      // Body fields
      assign(0,new Int4Field("error_code"));  
      assign(1,new StringField(512,"error_msg"));  
    }
};

//
// CREATE_REQ 
//

class UPSPCreateReq: public Message
{
  public:
    UPSPCreateReq():
      Message(32,"CREATE_REQ")
    {
      // Header fields
      assign(0,new Int4Field("length",469));  
      assign(1,new Int2Field("msg_type",UPSP_CREATE_REQ));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body fields
      assign(4,new StringField(33,"title"));  
      assign(5,new StringField(33,"first_name"));  
      assign(6,new StringField(33,"last_name"));  

      assign(7,new StringField(9,"middle_initial"));  
      assign(8,new StringField(9,"suffix"));  
      assign(9,new StringField(25,"phone_number"));  // Required
      assign(10,new StringField(25,"trusted_number"));  
      assign(11,new StringField(25,"fax_number")); 
      assign(12,new BoolField("has_dedicated_fax_number"));  

      assign(13,new StringField(25,"pass_code")); 
      assign(14,new BoolField("disabled"));  
      assign(15,new StringField(33,"host_name"));  
      assign(16,new BoolField("to_be_deleted"));  
      assign(17,new BoolField("trusted_phone_needs_password"));  
      assign(18,new BoolField("intl_calls"));  
      assign(19,new BoolField("mwi"));  
      assign(20,new BoolField("text_messaging"));  
      assign(21,new BoolField("oatm"));  

      assign(22,new BoolField("calls_fronted"));  
      assign(23,new StringField(17,"gip_cos"));  
      assign(24,new StringField(9,"pager_id"));  
      assign(25,new StringField(33,"initial_service","Basic")); // Required
      assign(26,new Int4Field("save_utterances_num_sessions"));  
      assign(27,new BoolField("restricted_presentation"));  
      assign(28,new StringField(33,"customer_defined1")); 
      assign(29,new StringField(33,"customer_defined2")); 
      assign(30,new StringField(33,"customer_defined3")); 
      assign(31,new StringField(33,"customer_defined4"));
    }
};

//
// CREATE_ACK 
//

class UPSPCreateAck: public Message
{
  public:
    UPSPCreateAck():
      Message(7,"CREATE_ACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",76));  
      assign(1,new Int2Field("msg_type",UPSP_CREATE_ACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body field
      assign(4,new StringField(25,"forward_on_busy"));
      assign(5,new StringField(33,"host_name"));
      assign(6,new Int4Field("current_capacity"));  
    }
};

//
// CREATE_ACK Body
//

class UPSPCreateAckBody: public Message
{
  public:
    UPSPCreateAckBody():
      Message(3,"CREATE_ACK_BODY")
    {
      // Body field
      assign(0,new StringField(25,"forward_on_busy"));
      assign(1,new StringField(33,"host_name"));
      assign(2,new Int4Field("current_capacity"));  
    }
};

//
// CREATE_NACK 
//

class UPSPCreateNAck: public Message
{
  public:
    UPSPCreateNAck():
      Message(6,"CREATE_NACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",530));  
      assign(1,new Int2Field("msg_type",UPSP_CREATE_NACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body field
      assign(4,new Int4Field("error_code"));  
      assign(5,new StringField(512,"error_msg"));  
    }
};

//
// CREATE_NACK Body
//

class UPSPCreateNAckBody: public Message
{
  public:
    UPSPCreateNAckBody():
      Message(2,"CREATE_NACK_BODY")
    {
      // Body field
      assign(0,new Int4Field("error_code"));  
      assign(1,new StringField(512,"error_msg"));  
    }
};

//
// SET_REQ 
//

class UPSPSetReq: public Message
{
  public:
    UPSPSetReq():
      Message(32,"SET_REQ")
    {
      // Header fields
      assign(0,new Int4Field("length",429));  
      assign(1,new Int2Field("msg_type",UPSP_SET_REQ));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body fields
      assign(4,new StringField(25,"current_phone_number")); // Required  
      assign(5,new StringField(33,"title"));  
      assign(6,new StringField(33,"first_name"));  
      assign(7,new StringField(33,"last_name"));  
      assign(8,new StringField(9,"middle_initial"));  
      assign(9,new StringField(9,"suffix"));  
      assign(10,new StringField(25,"new_phone_number")); 
      assign(11,new StringField(25,"trusted_number"));  
      assign(12,new StringField(25,"fax_number")); 
      assign(13,new BoolField("has_dedicated_fax_number"));  
      assign(14,new StringField(25,"pass_code")); 
      assign(15,new BoolField("clear_passcode"));  
      assign(16,new BoolField("disabled"));  
      assign(17,new BoolField("to_be_deleted"));  

      assign(18,new BoolField("trusted_phone_needs_password"));  
      assign(19,new BoolField("intl_calls"));  
      assign(20,new BoolField("mwi"));  
      assign(21,new BoolField("text_messaging"));  
      assign(22,new BoolField("oatm"));  

      assign(23,new BoolField("calls_fronted"));  
      assign(24,new StringField(17,"gip_cos"));  
      assign(25,new StringField(9,"pager_id"));  
      assign(26,new Int4Field("save_utterances_num_sessions"));  
      assign(27,new BoolField("restricted_presentation"));  
      assign(28,new StringField(33,"customer_defined1")); 
      assign(29,new StringField(33,"customer_defined2")); 
      assign(30,new StringField(33,"customer_defined3")); 
      assign(31,new StringField(33,"customer_defined4"));
    }
};

//
// SET_ACK 
//

class UPSPSetAck: public Message
{
  public:
    UPSPSetAck():
      Message(4,"SET_ACK")
    {
      // Header fields 
      assign(0,new Int4Field("length"));  
      assign(1,new Int2Field("msg_type"));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  
    }
};

//
// SET_NACK 
//

class UPSPSetNAck: public Message
{
  public:
    UPSPSetNAck():
      Message(6,"SET_NACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",530));  
      assign(1,new Int2Field("msg_type",UPSP_SET_NACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body field
      assign(4,new Int4Field("error_code"));  
      assign(5,new StringField(512,"error_msg"));  
    }
};

//
// SET_NACK Body
//

class UPSPSetNAckBody: public Message
{
  public:
    UPSPSetNAckBody():
      Message(2,"SET_NACK_BODY")
    {
      // Body field
      assign(0,new Int4Field("error_code"));  
      assign(1,new StringField(512,"error_msg"));  
    }
};

//
// GET_ALL_REQ 
//

class UPSPGetAllReq: public Message
{
  public:
    UPSPGetAllReq():
      Message(5,"GET_ALL_REQ")
    {
      // Header fields 
      assign(0,new Int4Field("length",39));  
      assign(1,new Int2Field("msg_type",UPSP_GET_ALL_REQ));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body field
      assign(4,new StringField(25,"phone_number"));  // Required
    }
};

//
// GET_ALL_ACK
//

class UPSPGetAllAck: public Message
{
  public:
    UPSPGetAllAck():
      Message(33,"GET_ALL_ACK")
    {
      // Header fields
      assign(0,new Int4Field("length",1100));  
      assign(1,new Int2Field("msg_type",UPSP_GET_ALL_ACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body fields
      assign(4,new StringField(33,"title"));  
      assign(5,new StringField(33,"first_name"));  
      assign(6,new StringField(33,"last_name"));  

      assign(7,new StringField(9,"middle_initial"));  
      assign(8,new StringField(9,"suffix"));  
      assign(9,new StringField(25,"phone_number")); 
      assign(10,new StringField(25,"trusted_number"));  
      assign(11,new StringField(25,"fax_number")); 
      assign(12,new BoolField("has_dedicated_fax_number"));  

      assign(13,new BoolField("disabled"));  
      assign(14,new StringField(33,"host_name"));  
      assign(15,new BoolField("to_be_deleted"));  
      assign(16,new BoolField("trusted_phone_needs_password"));  
      assign(17,new BoolField("intl_calls"));  
      assign(18,new BoolField("mwi"));  
      assign(19,new BoolField("text_messaging"));  
      assign(20,new BoolField("oatm"));  

      assign(21,new BoolField("calls_fronted"));  
      assign(22,new StringField(17,"gip_cos"));  
      assign(23,new StringField(9,"pager_id"));  
      assign(24,new StringField(25,"forward_on_busy")); 
      assign(25,new Int4Field("save_utterances_num_sessions"));  
      assign(26,new Int4Field("num_services"));  
      assign(27,new StringField(660,"service_name")); 
      assign(28,new BoolField("restricted_presentation"));  
      assign(29,new StringField(33,"customer_defined1")); 
      assign(30,new StringField(33,"customer_defined2")); 
      assign(31,new StringField(33,"customer_defined3")); 
      assign(32,new StringField(33,"customer_defined4"));
    }
};

//
// GET_ALL_ACK Body
//

class UPSPGetAllAckBody: public Message
{
  public:
    UPSPGetAllAckBody():
      Message(29,"GET_ALL_ACK_BODY")
    {
      // Body fields
      assign(0,new StringField(33,"title"));  
      assign(1,new StringField(33,"first_name"));  
      assign(2,new StringField(33,"last_name"));  

      assign(3,new StringField(9,"middle_initial"));  
      assign(4,new StringField(9,"suffix"));  
      assign(5,new StringField(25,"phone_number")); 
      assign(6,new StringField(25,"trusted_number"));  
      assign(7,new StringField(25,"fax_number")); 
      assign(8,new BoolField("has_dedicated_fax_number"));  

      assign(9,new BoolField("disabled"));  
      assign(10,new StringField(33,"host_name"));  
      assign(11,new BoolField("to_be_deleted"));  
      assign(12,new BoolField("trusted_phone_needs_password"));  
      assign(13,new BoolField("intl_calls"));  
      assign(14,new BoolField("mwi"));  
      assign(15,new BoolField("text_messaging"));  
      assign(16,new BoolField("oatm"));  

      assign(17,new BoolField("calls_fronted"));  
      assign(18,new StringField(17,"gip_cos"));  
      assign(19,new StringField(9,"pager_id"));  
      assign(20,new StringField(25,"forward_on_busy")); 
      assign(21,new Int4Field("save_utterances_num_sessions"));  
      assign(22,new Int4Field("num_services"));  
      assign(23,new StringField(660,"service_name")); 
      assign(24,new BoolField("restricted_presentation"));  
      assign(25,new StringField(33,"customer_defined1")); 
      assign(26,new StringField(33,"customer_defined2")); 
      assign(27,new StringField(33,"customer_defined3")); 
      assign(28,new StringField(33,"customer_defined4"));
    }
};

//
// GET_ALL_NACK 
//

class UPSPGetAllNAck: public Message
{
  public:
    UPSPGetAllNAck():
      Message(6,"SET_NACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",530));  
      assign(1,new Int2Field("msg_type",UPSP_GET_ALL_NACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body field
      assign(4,new Int4Field("error_code"));  
      assign(5,new StringField(512,"error_msg"));  
    }
};

//
// GET_ALL_NACK Body
//

class UPSPGetAllNAckBody: public Message
{
  public:
    UPSPGetAllNAckBody():
      Message(2,"GET_ALL_NACK_BODY")
    {
      // Body field
      assign(0,new Int4Field("error_code"));  
      assign(1,new StringField(512,"error_msg"));  
    }
};

//
// FIND_REQ
//

class UPSPFindReq: public Message
{
  public:
    UPSPFindReq():
      Message(6,"FIND_REQ")
    {
      // Header fields 
      assign(0,new Int4Field("length",80));  
      assign(1,new Int2Field("msg_type",UPSP_FIND_REQ));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body fields
      assign(4,new StringField(33,"first_name"));  
      assign(5,new StringField(33,"last_name"));  
    }
};

//
// FIND_ACK 
//

class UPSPFindAck: public Message
{
  public:
    UPSPFindAck():
      Message(6,"FIND_ACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",518));  
      assign(1,new Int2Field("msg_type",UPSP_FIND_ACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body fields
      assign(4,new Int4Field("num_phone_number"));  
      assign(5,new StringField(500,"phone_number"));  
    }
};

//
// FIND_ACK Body
//

class UPSPFindAckBody: public Message
{
  public:
    UPSPFindAckBody():
      Message(2,"FIND_ACK_BODY")
    {
      // Body fields
      assign(0,new Int4Field("num_phone_number"));  
      assign(1,new StringField(500,"phone_number"));  
    }
};

//
// FIND_NACK 
//

class UPSPFindNAck: public Message
{
  public:
    UPSPFindNAck():
      Message(6,"FIND_NACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",530));  
      assign(1,new Int2Field("msg_type",UPSP_FIND_NACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body field
      assign(4,new Int4Field("error_code"));  
      assign(5,new StringField(512,"error_msg"));  
    }
};

//
// FIND_NACK Body
//

class UPSPFindNAckBody: public Message
{
  public:
    UPSPFindNAckBody():
      Message(2,"FIND_NACK_BODY")
    {
      // Body field
      assign(0,new Int4Field("error_code"));  
      assign(1,new StringField(512,"error_msg"));  
    }
};

//
// REMOVE_SUBSC_REQ
//

class UPSPRemoveSubscReq: public Message
{
  public:
    UPSPRemoveSubscReq():
      Message(6,"REMOVE_SUBSC_REQ")
    {
      // Header fields 
      assign(0,new Int4Field("length",72));  
      assign(1,new Int2Field("msg_type",UPSP_REMOVE_SUBSC_REQ));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body fields
      assign(4,new StringField(25,"phone_number"));  
      assign(5,new StringField(33,"notification_service"));  
    }
};

//
// REMOVE_SUBSC_ACK 
//

class UPSPRemoveSubscAck: public Message
{
  public:
    UPSPRemoveSubscAck():
      Message(4,"REMOVE_SUBSC_ACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",14));  
      assign(1,new Int2Field("msg_type",UPSP_REMOVE_SUBSC_ACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  
    }
};

//
// REMOVE_SUBSC_NACK 
//

class UPSPRemoveSubscNAck: public Message
{
  public:
    UPSPRemoveSubscNAck():
      Message(6,"REMOVE_SUBSC_NACK")
    {
      // Header fields 
      assign(0,new Int4Field("length",530));  
      assign(1,new Int2Field("msg_type",UPSP_REMOVE_SUBSC_NACK));
      assign(2,new Int4Field("client_data_1"));  
      assign(3,new Int4Field("client_data_2"));  

      // Body field
      assign(4,new Int4Field("error_code"));  
      assign(5,new StringField(512,"error_msg"));  
    }
};

//
// REMOVE_SUBSC_NACK Body
//

class UPSPRemoveSubscNAckBody: public Message
{
  public:
    UPSPRemoveSubscNAckBody():
      Message(2,"REMOVE_SUBSC_NACK_BODY")
    {
      // Body field
      assign(0,new Int4Field("error_code"));  
      assign(1,new StringField(512,"error_msg"));  
    }
};

#endif

/* end of file */
