// $Id$

//  myexpr - My Service Expression Engine - Version 1.0 (www.mysvc.it)
//  Copyright (C) 2009 Davide Cucciniello <davide6169@gmail.com> 
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

/* **********************************************************************
 *
 *  ***   **        *** **  **  **** 
 *   **  **        *  *  *  ** **  * 
 *   *** **  **  * ***   *  *  *     
 *   * ** *   * **   **   * *  *     
 *   * *  *   * *  *  *   **   **    
 *  ***  ***   **  ***     *    **** 
 *             *                     
 *            *                      
 *
 *  My Service
 *
 * ***********************************************************************
 *
 *  ***   **       *****                  
 *   **  **         *  *                  
 *   *** **  **  *  ***  ***** ****  **** 
 *   * ** *   * **  *     ***   *  *  * * 
 *   * *  *   * *   *  *  ***   *  *  *   
 *  ***  ***   **  ***** ** **  ***  ***  
 *             *                *         
 *            *                *** 
 *                                
 *  My Service Expression Engine
 *
 *  File: Expr.java 
 *
 *  Description: 
 *    class Expr: Syntax tree of an expression 
 *    MyExpr: Java library implementing an advanced generic 
 *    expression parser based on precedence operator
 *
 * ***********************************************************************
 *
 *  History:
 *    1.0               first version
 *
 * *********************************************************************** */

package it.mysvc.myexpr;

public class Expr
{
  private int code;
  private String info;
  private boolean prefix;
  private Expr left,right;

  public Expr()
  {
  }

  public Expr(int code)
  {
    this.code = code;
  }

  public Expr(int code,String info)
  {
    this.code = code;
    this.info = info;
  }

  public Expr(int unaryOperator,Expr left)
  {
    this(unaryOperator,left,true);
  }

  public Expr(int unaryOperator,Expr left,boolean prefix)
  {
    this.code = unaryOperator; 
    this.prefix = prefix;
    this.left = left;
  }

  public Expr(int unaryOperator,String info,Expr left)
  {
    this(unaryOperator,info,left,true);
  }

  public Expr(int unaryOperator,String info,Expr left,boolean prefix)
  {
    this.code = unaryOperator; 
    this.prefix = prefix; 
    this.info = info;
    this.left = left;
  }

  public Expr(int binaryOperator,Expr left,Expr right)
  {
    this.code = binaryOperator;
    this.left = left;
    this.right = right;
  }

  public Expr(int binaryOperator,String info,Expr left,Expr right)
  {
    this.code = binaryOperator;
    this.info = info;
    this.left = left;
    this.right = right;
  }

  public void setCode(int code)
  {
    this.code = code;
  }

  public int getCode()
  {
    return code;
  }

  public void setInfo(String info)
  {
    this.info = info;
  }

  public String getInfo()
  {
    return info;
  }

  public void setPrefix(boolean prefix)
  {
    this.prefix = prefix;
  }

  public boolean isPrefix()
  {
    return prefix;
  }

  public void setLeft(Expr left)
  {
    this.left = left;
  }

  public Expr getLeft()
  {
    return left;
  }
 
  public void setRight(Expr right)
  {
    this.right = right;
  }

  public Expr getRight()
  {
    return right;
  } 

  public boolean isOperand()
  {
    return (left==null)&&(right==null);
  }

  public boolean isUnaryOperator()
  {
    return (left!=null)&&(right==null);
  }

  public boolean isBinaryOperator()
  {
    return (left!=null)&&(right!=null);
  }

  public Expr clone(Factory factory)
  {
    if((left==null)&&(right==null))
      return factory.getExpr(code,info); 
    else if((left!=null)&&(right==null))
      return factory.getExpr(code,info,left.clone(factory),prefix);
    else
      return factory.getExpr(code,info,left.clone(factory),right.clone(factory));
  }
 
  public String toString(Printer printer,boolean fullParenthesis)
  { 
    return printer.toString(this,fullParenthesis);
  }

  public String toString(Printer printer)
  { 
    return printer.toString(this); 
  }
}

/* end of file */
