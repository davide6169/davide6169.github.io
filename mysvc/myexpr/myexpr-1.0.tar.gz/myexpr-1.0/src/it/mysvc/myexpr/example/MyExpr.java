// $Id$

//  myexpr - My Service Expression Engine - Version 1.0 (www.mysvc.it)
//  Copyright (C) 2009 Davide Cucciniello <davide6169@gmail.com> 
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

/* **********************************************************************
 *
 *  ***   **        *** **  **  **** 
 *   **  **        *  *  *  ** **  * 
 *   *** **  **  * ***   *  *  *     
 *   * ** *   * **   **   * *  *     
 *   * *  *   * *  *  *   **   **    
 *  ***  ***   **  ***     *    **** 
 *             *                     
 *            *                      
 *
 *  My Service
 *
 * ***********************************************************************
 *
 *  ***   **       *****                  
 *   **  **         *  *                  
 *   *** **  **  *  ***  ***** ****  **** 
 *   * ** *   * **  *     ***   *  *  * * 
 *   * *  *   * *   *  *  ***   *  *  *   
 *  ***  ***   **  ***** ** **  ***  ***  
 *             *                *         
 *            *                *** 
 *                                
 *  My Service Expression Engine
 *
 *  File: MyExpr.java 
 *
 *  Description: 
 *    class MyExpr: Syntax tree of a propositional logic expression 
 *    MyExpr: Java library implementing an advanced generic 
 *    expression parser based on precedence operator
 *
 * ***********************************************************************
 *
 *  History:
 *    1.0               first version
 *
 * *********************************************************************** */

package it.mysvc.myexpr.example;

import it.mysvc.myexpr.*;

public class MyExpr extends Expr
{
  public MyExpr()
  {
  }

  public MyExpr(int code)
  {
    super(code);    
  }

  public MyExpr(int code,String info)
  {
    super(code,info);    
  }

  public MyExpr(int unaryOperator,Expr left)
  {
    super(unaryOperator,left);    
  }

  public MyExpr(int unaryOperator,Expr left,boolean prefix)
  {
    super(unaryOperator,left,prefix);    
  }

  public MyExpr(int unaryOperator,String info,Expr left)
  {
    super(unaryOperator,info,left);    
  }

  public MyExpr(int unaryOperator,String info,Expr left,boolean prefix)
  {
    super(unaryOperator,info,left,prefix);    
  }

  public MyExpr(int binaryOperator,Expr left,Expr right)
  {
    super(binaryOperator,left,right);    
  }

  public MyExpr(int binaryOperator,String info,Expr left,Expr right)
  {
    super(binaryOperator,info,left,right);    
  }

  public MyExpr X()
  {
    return (MyExpr)getLeft();
  }

  public MyExpr Y()
  {
    return (MyExpr)getRight();
  }

  public void setX(MyExpr x)
  {
    setLeft(x);
  }

  public void setY(MyExpr y)
  {
    setRight(y);
  }

  public int value()
  {
    if(isVariable())
      return getCode();
    else
      return -(X().getCode());
  }

  public boolean isTrue()
  {
    return isOperand()&&(getCode()==MyExprOperators.TRUE);
  }

  public boolean isFalse()
  {
    return isOperand()&&(getCode()==MyExprOperators.FALSE);
  }

  public boolean isConst()
  {
    return isTrue()||isFalse();
  }

  public boolean isNot()
  {
    return isUnaryOperator()&&(getCode()==MyExprOperators.NOT);
  }

  public boolean isNotOperand()
  {
    return isNot()&&getLeft().isOperand();
  }

  public boolean isLiteral()
  {
    return isOperand()||isNotOperand();
  }

  public boolean isAnd()
  {
    return isBinaryOperator()&&(getCode()==MyExprOperators.AND);
  }

  public boolean isOr()
  {
    return isBinaryOperator()&&(getCode()==MyExprOperators.OR);
  }

  public boolean isImplies()
  {
    return isBinaryOperator()&&(getCode()==MyExprOperators.IMPLIES);
  }

  public boolean isEquivalent()
  {
    return isBinaryOperator()&&(getCode()==MyExprOperators.EQUIVALENT);
  }

  public boolean isNotNot()
  {
    return isNot()&&((MyExpr)getLeft()).isNot();
  }

  public boolean isNotAnd()
  {
    return isNot()&&((MyExpr)getLeft()).isAnd();
  }

  public boolean isNotOr()
  {
    return isNot()&&((MyExpr)getLeft()).isOr();
  }

  public boolean isNotTrue()
  {
    return isNot()&&((MyExpr)getLeft()).isTrue();
  }

  public boolean isNotFalse()
  {
    return isNot()&&((MyExpr)getLeft()).isFalse();
  }

  public boolean isTrueAndX()
  {
    return isAnd()&&((MyExpr)getLeft()).isTrue();
  }

  public boolean isXAndTrue()
  {
    return isAnd()&&((MyExpr)getRight()).isTrue();
  }

  public boolean isFalseAndX()
  {
    return isAnd()&&((MyExpr)getLeft()).isFalse();
  }

  public boolean isXAndFalse()
  {
    return isAnd()&&((MyExpr)getRight()).isFalse();
  }

  public boolean isTrueOrX()
  {
    return isOr()&&((MyExpr)getLeft()).isTrue();
  }

  public boolean isXOrTrue()
  {
    return isOr()&&((MyExpr)getRight()).isTrue();
  }

  public boolean isFalseOrX()
  {
    return isOr()&&((MyExpr)getLeft()).isFalse();
  }

  public boolean isXOrFalse()
  {
    return isOr()&&((MyExpr)getRight()).isFalse();
  }

  public boolean isVariable()
  {
    return isOperand();
  }

  public boolean isUnknown(int t)
  {
    return (t == -1);
  }

  public boolean isTrue(int t)
  {
    return (t == 1);
  }

  public boolean isFalse(int t)
  {
    return (t == 0);
  }

  public int getTruth() 
  {
    if(isAnd())
    {
      int x = X().getTruth();

      if(isFalse(x))
        return 0;
      else if(isTrue(x))
        return Y().getTruth();
      else if(isFalse(Y().getTruth()))
        return 0;
      else
        return -1;
    }
    else if(isOr())
    {
      int x = X().getTruth();

      if(isTrue(x))
        return 1;
      else if(isFalse(x))
        return Y().getTruth();
      else if(isTrue(Y().getTruth()))
        return 1;
      else
        return -1;
    }
    else if(isImplies())
    {
      int x = X().getTruth();

      if(isFalse(x))
        return 1;
      else if(isTrue(x))
        return Y().getTruth();
      else if(isTrue(Y().getTruth()))
        return 1;
      else
        return -1;
    }
    else if(isEquivalent())
    {
      int x = X().getTruth();

      if(isUnknown(x))
        return -1;
      else
      {
        int y = Y().getTruth();

        if(isUnknown(y))
          return -1;
        else if(x == y)
          return 1;
        else
          return 0;
      }
    }
    else if(isVariable())
    {
      if(isTrue())
        return 1;
      else if(isFalse())
        return 0;
      else
        return -1;
    }
    else if(isNot())
    {
      int x = X().getTruth();

      if(isTrue(x))
        return 0;
      else if(isFalse(x))
        return 1;
      else
        return -1;
    }
    else
      return -1;
  }

  public static MyExpr Variable(int code)
  {
    return new MyExpr(code);
  }

  public static MyExpr Variable(int code,String info)
  {
    return new MyExpr(code,info);
  }

  public static MyExpr Not(MyExpr expr)
  {
    return new MyExpr(MyExprOperators.NOT,expr);
  }

  public static MyExpr Not(String info,MyExpr expr)
  {
    return new MyExpr(MyExprOperators.NOT,info,expr);
  }

  public static MyExpr And(MyExpr left,MyExpr right)
  {
    return new MyExpr(MyExprOperators.AND,left,right);
  }

  public static MyExpr And(String info,MyExpr left,MyExpr right)
  {
    return new MyExpr(MyExprOperators.AND,info,left,right);
  }

  public static MyExpr Or(MyExpr left,MyExpr right)
  {
    return new MyExpr(MyExprOperators.OR,left,right);
  }

  public static MyExpr Or(String info,MyExpr left,MyExpr right)
  {
    return new MyExpr(MyExprOperators.OR,info,left,right);
  }

  public static MyExpr Implies(MyExpr left,MyExpr right)
  {
    return new MyExpr(MyExprOperators.IMPLIES,left,right);
  }

  public static MyExpr Implies(String info,MyExpr left,MyExpr right)
  {
    return new MyExpr(MyExprOperators.IMPLIES,info,left,right);
  }

  public static MyExpr Equivalent(MyExpr left,MyExpr right)
  {
    return new MyExpr(MyExprOperators.EQUIVALENT,left,right);
  }

  public static MyExpr Equivalent(String info,MyExpr left,MyExpr right)
  {
    return new MyExpr(MyExprOperators.EQUIVALENT,info,left,right);
  }

  public static MyExpr True()
  {
    return new MyExpr(MyExprOperators.TRUE);
  }

  public static MyExpr True(String info)
  {
    return new MyExpr(MyExprOperators.TRUE,info);
  }

  public static MyExpr False()
  {
    return new MyExpr(MyExprOperators.FALSE);
  }

  public static MyExpr False(String info)
  {
    return new MyExpr(MyExprOperators.FALSE,info);
  }

  public MyExpr rewriteImplies()
  {
    if(isImplies())
      return Or(Not(X()),Y());
    else if(isUnaryOperator())
    {
      setX(X().rewriteImplies());

      return this;
    }
    else if(isBinaryOperator())
    {
      setX(X().rewriteImplies());
      setY(Y().rewriteImplies());

      return this;
    }
    else
      return this;
  }

  public MyExpr rewriteEquivalent()
  {
    if(isEquivalent())
      return And(Or(Not(X()),Y()),Or(Not(Y()),X()));
    else if(isUnaryOperator())
    {
      setX(X().rewriteEquivalent());

      return this;
    }
    else if(isBinaryOperator())
    {
      setX(X().rewriteEquivalent());
      setY(Y().rewriteEquivalent());

      return this;
    }
    else
      return this;
  }

  public MyExpr reduceNNF()
  {
    MyExpr e = this; 

    while(e.isNotNot())
      e = e.X().X();

    if(e.isNotTrue())
      return False(); 
    else if(e.isNotFalse())
      return True(); 
    else if(isNotOr())
      e = And(Not(e.X().X()),Not(e.X().Y())); 
    else if(isNotAnd())
      e = Or(Not(e.X().X()),Not(e.X().Y())); 
   
    if(e.isBinaryOperator()) 
    {
      e.setX(e.X().reduceNNF());
      e.setY(e.Y().reduceNNF());
    }

    return e;
  }

  public MyExpr normalize()
  {
    MyExpr e = this; 

    e = e.rewriteImplies();
    e = e.rewriteEquivalent();
    e = e.reduceNNF();

    return e;
  }

  int Value()
  {
    if(isVariable())
      return getCode();
    else
      return -(X().getCode());
  }

  public MyExpr remove()
  {
    if(isVariable())
      return this; 
    else if(isUnaryOperator())
      setX(X().remove());
    else
    {
      setX(X().remove());
      setY(Y().remove());
    }

    if(isTrueAndX()) 
      return Y();
    else if(isXAndTrue()) 
      return X();
    else if(isTrueOrX()||isXOrTrue()) 
      return True();
    else if(isNotTrue())
      return False();
    else if(isNotFalse())
      return True();
    else if(isFalseOrX()) 
      return Y();
    else if(isXOrFalse()) 
      return X();
    else if(isFalseAndX()||isXAndFalse()) 
      return False();
    else
      return this;
  }

  public MyExpr simplify()
  {
    return remove(); 
  }
}

/* end of file */
