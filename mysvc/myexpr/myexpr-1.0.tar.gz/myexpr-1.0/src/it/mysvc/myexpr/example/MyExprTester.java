// $Id$

//  myexpr - My Service Expression Engine - Version 1.0 (www.mysvc.it)
//  Copyright (C) 2009 Davide Cucciniello <davide6169@gmail.com> 
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

/* **********************************************************************
 *
 *  ***   **        *** **  **  **** 
 *   **  **        *  *  *  ** **  * 
 *   *** **  **  * ***   *  *  *     
 *   * ** *   * **   **   * *  *     
 *   * *  *   * *  *  *   **   **    
 *  ***  ***   **  ***     *    **** 
 *             *                     
 *            *                      
 *
 *  My Service
 *
 * ***********************************************************************
 *
 *  ***   **       *****                  
 *   **  **         *  *                  
 *   *** **  **  *  ***  ***** ****  **** 
 *   * ** *   * **  *     ***   *  *  * * 
 *   * *  *   * *   *  *  ***   *  *  *   
 *  ***  ***   **  ***** ** **  ***  ***  
 *             *                *         
 *            *                *** 
 *                                
 *  My Service Expression Engine
 *
 *  File: MyExprTester.java 
 *
 *  Description: 
 *    class MyExprTester: example application for MyExpr library usage
 *    MyExpr: Java library implementing an advanced generic 
 *    expression parser based on precedence operator
 *
 * ***********************************************************************
 *
 *  History:
 *    1.0               first version
 *
 * *********************************************************************** */

package it.mysvc.myexpr.example;

import it.mysvc.myexpr.*;

public class MyExprTester
{
  public static void main(String[] args)
  {
    try
    {
      Parser parser = new Parser(new MyExprOperators(),new MyExprLexer(),new MyExprFactory());
      Writer writer = new MyExprWriter();
      Printer printer = new Printer(parser,writer);

      Expr expr = parser.parse("~(x1|x2)");

      System.out.println(expr.toString(printer));

      Expr expr2 = expr.clone(new MyExprFactory());

      expr = ((MyExpr)expr).normalize();

      System.out.println(expr.toString(printer));
      
      System.out.println(expr2.toString(printer));
    }
    catch(SyntaxException e)
    {
      System.out.println("Syntax Exception");
      System.out.println("expr {" + e.getExpr() + "}");
      System.out.println("queue {" + e.getQueue() + "}");
      System.out.println("token {" + e.getToken() + "}");
      System.out.println("type {" + e.getType() + "}");
      System.out.println("character {" + e.getCharacter() + "}");
      System.out.println("position {" + e.getPosition() + "}");
    }
  }
}

/* end of file */
