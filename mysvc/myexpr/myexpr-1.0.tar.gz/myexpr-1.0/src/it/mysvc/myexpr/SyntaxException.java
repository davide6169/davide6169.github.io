// $Id$

//  myexpr - My Service Expression Engine - Version 1.0 (www.mysvc.it)
//  Copyright (C) 2009 Davide Cucciniello <davide6169@gmail.com> 
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

/* **********************************************************************
 *
 *  ***   **        *** **  **  **** 
 *   **  **        *  *  *  ** **  * 
 *   *** **  **  * ***   *  *  *     
 *   * ** *   * **   **   * *  *     
 *   * *  *   * *  *  *   **   **    
 *  ***  ***   **  ***     *    **** 
 *             *                     
 *            *                      
 *
 *  My Service
 *
 * ***********************************************************************
 *
 *  ***   **       *****                  
 *   **  **         *  *                  
 *   *** **  **  *  ***  ***** ****  **** 
 *   * ** *   * **  *     ***   *  *  * * 
 *   * *  *   * *   *  *  ***   *  *  *   
 *  ***  ***   **  ***** ** **  ***  ***  
 *             *                *         
 *            *                *** 
 *                                
 *  My Service Expression Engine
 *
 *  File: SyntaxException.java 
 *
 *  Description: 
 *    class SyntaxException: Syntax Exception parsing an expression 
 *    MyExpr: Java library implementing an advanced generic 
 *    expression parser based on precedence operator
 *
 * ***********************************************************************
 *
 *  History:
 *    1.0               first version
 *
 * *********************************************************************** */

package it.mysvc.myexpr;

public class SyntaxException extends Exception
{
  enum Type
  {
    EmptyExpression,
    UnknownToken,
    InvalidOperand,
    InvalidUnaryOperator,
    InvalidBinaryOperator,
    InvalidOpenedParenthesis,
    InvalidClosedParenthesis,
    OpenedParenthesisExpected,
    ClosedParenthesisExpected
  };

  private String expr;
  private String queue;
  private String token;
  private Type type;
  private int character;
  private int position;

  public SyntaxException(String expr,String queue,String token,Type type,int position,int character)
  {
    super("syntax error on expression "+ expr + " : " + type + " (token " + token + ", character " + character + ")");

    this.expr = expr;
    this.queue = queue;
    this.token = token;
    this.type = type;
    this.character = character;
    this.position = position;
  }

  public String getExpr()
  {
    return expr;
  }

  public String getQueue()
  {
    return queue;
  }

  public String getToken()
  {
    return token;
  }

  public Type getType()
  {
    return type;
  }

  public int getCharacter()
  {
    return character;
  }

  public int getPosition()
  {
    return position;
  }
}

/* end of file */
