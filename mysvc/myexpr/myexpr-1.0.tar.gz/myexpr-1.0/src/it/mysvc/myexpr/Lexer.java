// $Id$

//  myexpr - My Service Expression Engine - Version 1.0 (www.mysvc.it)
//  Copyright (C) 2009 Davide Cucciniello <davide6169@gmail.com> 
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

/* **********************************************************************
 *
 *  ***   **        *** **  **  **** 
 *   **  **        *  *  *  ** **  * 
 *   *** **  **  * ***   *  *  *     
 *   * ** *   * **   **   * *  *     
 *   * *  *   * *  *  *   **   **    
 *  ***  ***   **  ***     *    **** 
 *             *                     
 *            *                      
 *
 *  My Service
 *
 * ***********************************************************************
 *
 *  ***   **       *****                  
 *   **  **         *  *                  
 *   *** **  **  *  ***  ***** ****  **** 
 *   * ** *   * **  *     ***   *  *  * * 
 *   * *  *   * *   *  *  ***   *  *  *   
 *  ***  ***   **  ***** ** **  ***  ***  
 *             *                *         
 *            *                *** 
 *                                
 *  My Service Expression Engine
 *
 *  File: Lexer.java 
 *
 *  Description: 
 *    interface Lexer: Lexical Analyzer of an expression 
 *    MyExpr: Java library implementing an advanced generic 
 *    expression parser based on precedence operator
 *
 * ***********************************************************************
 *
 *  History:
 *    1.0               first version
 *
 * *********************************************************************** */

package it.mysvc.myexpr;

public interface Lexer
{
  String[] getBlanks();

  String[] getBinaryOperators();
  String[] getUnaryOperators();
  String[] getOperands();
  String[] getOpenedParenthesis();
  String[] getClosedParenthesis();

  int getBinaryOperator(int type,String binaryOperator);
  int getUnaryOperator(int type,String unaryOperator);
  int getOperand(int type,String operand);
  int getOpenedParenthesis(int type,String openedParenthesis);
  int getClosedParenthesis(int type,String closedParenthesis);

  String getBinaryOperator(String binaryOperator);
  String getUnaryOperator(String unaryOperator);
  String getOperand(String operand);
  String getOpenedParenthesis(String openedParenthesis);
  String getClosedParenthesis(String closedParenthesis);

  Token getToken(Token token); 
}

/* end of file */
