// $Id$

//  myexpr - My Service Expression Engine - Version 1.0 (www.mysvc.it)
//  Copyright (C) 2009 Davide Cucciniello <davide6169@gmail.com> 
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

/* **********************************************************************
 *
 *  ***   **        *** **  **  **** 
 *   **  **        *  *  *  ** **  * 
 *   *** **  **  * ***   *  *  *     
 *   * ** *   * **   **   * *  *     
 *   * *  *   * *  *  *   **   **    
 *  ***  ***   **  ***     *    **** 
 *             *                     
 *            *                      
 *
 *  My Service
 *
 * ***********************************************************************
 *
 *  ***   **       *****                  
 *   **  **         *  *                  
 *   *** **  **  *  ***  ***** ****  **** 
 *   * ** *   * **  *     ***   *  *  * * 
 *   * *  *   * *   *  *  ***   *  *  *   
 *  ***  ***   **  ***** ** **  ***  ***  
 *             *                *         
 *            *                *** 
 *                                
 *  My Service Expression Engine
 *
 *  File: MyExprOperators.java 
 *
 *  Description: 
 *    class MyExprOperators: Operators of a propositional logic expression
 *    MyExpr: Java library implementing an advanced generic 
 *    expression parser based on precedence operator
 *
 * ***********************************************************************
 *
 *  History:
 *    1.0               first version
 *
 * *********************************************************************** */

package it.mysvc.myexpr.example;

import it.mysvc.myexpr.*;

public class MyExprOperators implements Operators
{
  // binary operators
  public static final int AND         = 0;
  public static final int OR          = 1;
  public static final int IMPLIES     = 2;
  public static final int EQUIVALENT  = 3;
  public static final int ASSIGN      = 4;

  // unary operator
  public static int NOT               = 0;

  // constants TRUE and FALSE
  public static final int TRUE        = -1;
  public static final int FALSE       = 0;

  public int getBinaryOperators()
  {
    return 5;
  }

  public int getPrecedence(int binaryOperator)
  {
    switch(binaryOperator)
    {
      // AND
      case 0:
        return 5;
      // OR
      case 1:
        return 4;
      // IMPLIES
      case 2:
        return 3;
      // EQUIVALENT
      case 3:
        return 2;
      // ASSIGN
      default:
        return 1;
    }
  }

  public boolean isLeftAssociative(int binaryOperator)
  {
    return true;
  }

  public boolean isPrefix(int unaryOperator)
  {
    return true; 
  }

  public boolean isPostfix(int unaryOperator)
  {
    return true; 
  }
}

/* end of file */
