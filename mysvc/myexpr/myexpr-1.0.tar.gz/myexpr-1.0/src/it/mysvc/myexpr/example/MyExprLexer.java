// $Id$

//  myexpr - My Service Expression Engine - Version 1.0 (www.mysvc.it)
//  Copyright (C) 2009 Davide Cucciniello <davide6169@gmail.com> 
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

/* **********************************************************************
 *
 *  ***   **        *** **  **  **** 
 *   **  **        *  *  *  ** **  * 
 *   *** **  **  * ***   *  *  *     
 *   * ** *   * **   **   * *  *     
 *   * *  *   * *  *  *   **   **    
 *  ***  ***   **  ***     *    **** 
 *             *                     
 *            *                      
 *
 *  My Service
 *
 * ***********************************************************************
 *
 *  ***   **       *****                  
 *   **  **         *  *                  
 *   *** **  **  *  ***  ***** ****  **** 
 *   * ** *   * **  *     ***   *  *  * * 
 *   * *  *   * *   *  *  ***   *  *  *   
 *  ***  ***   **  ***** ** **  ***  ***  
 *             *                *         
 *            *                *** 
 *                                
 *  My Service Expression Engine
 *
 *  File: MyExprLexer.java 
 *
 *  Description: 
 *    class MyExprLexer: Lexical Analyzer of a propositional logic expression
 *    MyExpr: Java library implementing an advanced generic 
 *    expression parser based on precedence operator
 *
 * ***********************************************************************
 *
 *  History:
 *    1.0               first version
 *
 * *********************************************************************** */

package it.mysvc.myexpr.example;

import it.mysvc.myexpr.*;

public class MyExprLexer implements Lexer
{
  public String[] getBlanks()
  {
    return new String[]
    {
      "\\s+",
      "//.*\n",
      "/\\*.*\\*/"
    };
  }

  public String[] getBinaryOperators()
  {
    return new String[]
    {
      "&|and|\\*",
      "\\||or|\\+",
      "->|implies",
      "<->|iff",
      "=|is"
    };
  }

  public String[] getUnaryOperators()
  {
    return new String[]
    {
      "-|~|!|not",
      "\\[[0-9]*\\]",
      "<[0-9]*>"
    };
  }

  public String[] getOperands()
  {
    return new String[]
    {
      "[a-zA-Z][0-9]+",
      "true|T|t|1",
      "false|F|f|0"
    };
  }

  public String[] getOpenedParenthesis()
  {
    return new String[]
    {
      "\\(|\\{"
    };
  }

  public String[] getClosedParenthesis()
  {
    return new String[]
    {
      "\\)|\\}"
    };
  }

  public int getBinaryOperator(int type,String binaryOperator)
  {
    return type;
  }

  public int getUnaryOperator(int type,String unaryOperator)
  {
    if(unaryOperator.matches("-|~|!|not")) 
      return 0;
    else if(unaryOperator.matches("\\[[0-9]*\\]")) 
      return Integer.parseInt(unaryOperator.substring(1,unaryOperator.length()-2));
    else
      return -1*Integer.parseInt(unaryOperator.substring(1,unaryOperator.length()-2));
  }

  public int getOperand(int type,String operand)
  {
    if(type==0)
      return Integer.parseInt(operand.substring(1));
    else if(type==1)
      return -1;
    else
      return 0;
  }

  public int getOpenedParenthesis(int type,String openedParenthesis)
  {
    return '(';
  }

  public int getClosedParenthesis(int type,String closedParenthesis)
  {
    return ')';
  }

  public String getBinaryOperator(String binaryOperator)
  {
    return binaryOperator;
  }

  public String getUnaryOperator(String unaryOperator)
  {
    return unaryOperator;
  }

  public String getOperand(String operand)
  {
    return operand.toUpperCase();
  }

  public String getOpenedParenthesis(String openedParenthesis)
  {
    return openedParenthesis;
  }

  public String getClosedParenthesis(String closedParenthesis)
  {
    return closedParenthesis;
  }

  public Token getToken(Token token)
  {
    return token;
  }
}

/* end of file */
